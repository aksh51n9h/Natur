package com.aksh.dev.home.p

import androidx.lifecycle.ViewModel;

class ItemViewViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
