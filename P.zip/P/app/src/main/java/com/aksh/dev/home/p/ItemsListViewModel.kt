package com.aksh.dev.home.p

import androidx.lifecycle.ViewModel;

class ItemsListViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
