package com.aksh.dev.home.p.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "items_table")
data class Item(
        @PrimaryKey(autoGenerate = true) val id: Int = 0,
        var name: String,
        var category: String,
        var photoUrl: String
)